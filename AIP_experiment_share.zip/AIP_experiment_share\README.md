# AIP Lecture Recommendation Experiment Share

이 폴더는 조원 검토용 공유 패키지입니다. 코드, 정규화 데이터, 모델 입력 데이터, 실험 결과를 포함합니다.

## 먼저 볼 파일

1. `data/experiments/full_cv/cv_presentation_summary.md`
   - 06/08 발표 요구사항 기준 요약
   - 전체 데이터, cross-validation, hyperparameter search, qualitative analysis, 장단점 정리

2. `data/experiments/full_cv/cv_summary.csv`
   - 5-fold cross-validation 결과 요약
   - 모델별/하이퍼파라미터별 MSE, RMSE, MAE 평균 및 표준편차

3. `data/experiments/full_cv/qualitative_top10_scenarios.csv`
   - 선호 시나리오별 Top-10 추천 후보

4. `data/experiments/full_cv/*.svg`
   - 발표용 그래프

## 주요 결과

전체 데이터 기준:

- 강의 노드: 753개
- Feature: 31개
- Target: `rating_average_norm`
- Cross-validation: 5-fold

Best model:

```text
Ridge Regression alpha=10
CV MSE  0.00319527
CV RMSE 0.05641645
CV MAE  0.04178956
```

## 폴더 구조

```text
scripts/
  build_text_features.py
  build_lecture_nodes.py
  run_small_portion_experiment.py
  run_full_cv_experiment.py
  make_cv_visuals.py
  ...

crawler_src/
  api_client.py
  collect.py
  config.py

data/
  normalized/
    lecture_articles.csv
    lecture_details.csv
    exam_question_types.csv
    books.csv

  model/
    lecture_nodes.csv
    lecture_nodes_with_text.csv
    lecture_text_features.csv
    lecture_top_keywords.csv

  experiments/
    small_portion/
    full_data/
    full_cv/
```

## 재현 방법

Python 실행 파일은 각자 환경에 맞게 `python`으로 바꿔도 됩니다.

```powershell
python scripts\build_lecture_nodes.py
python scripts\build_text_features.py
python scripts\run_full_cv_experiment.py
python scripts\make_cv_visuals.py
```

## 포함하지 않은 것

원본 raw JSON 전체는 공유 패키지에 포함하지 않았습니다.

이유:

- 강의평 원문 raw는 용량이 크고 민감할 수 있음
- 실험 검토에는 정규화된 CSV와 모델 입력 데이터만으로 충분함

필요하면 원본 raw는 별도 공유해야 합니다.

## 현재 한계

- 과목명/교수명 metadata가 없음
- 학생별 수강/평가 이력이 없음
- 현재 검증 target은 개인화 추천 정확도가 아니라 평균 평점 예측
- 실제 개인화 추천 검증에는 Hit@K, NDCG@K 등 지표와 학생 이력 데이터가 필요함
